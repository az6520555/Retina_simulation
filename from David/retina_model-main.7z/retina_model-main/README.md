# retina_model
Simulation of feedforward and feedback inhibition in retina <br> 
The model can explain mechanism of prediction in retina  <br> 
Code is written in python  <br> 
